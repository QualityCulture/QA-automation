﻿using Feb2017.Pages;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Feb2017
{
    class Program
    {
        static void Main(string[] args)
        {
            //Define Chrome Driver
            IWebDriver driver = new ChromeDriver();

            //Page object for Login Page
            LoginPage LoginObject = new LoginPage();
            LoginObject.LoginStep(driver);

            //Page object for Button Page
            ButtonPage ButtonObject = new ButtonPage();
            ButtonObject.AddButton(driver);        

        }
    }
}
