﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Feb2017.Pages
{
    class LoginPage
    {
        public void LoginStep(IWebDriver driver)
        {


            //Lauch the url
            driver.Navigate().GoToUrl("https://demo.econz.co.nz:1000/AdminPortal/Account/Login/exptest");

            //Maximize browser
            driver.Manage().Window.Maximize();

            //Username definition and input
            IWebElement Username = driver.FindElement(By.Id("UserName"));
            Username.SendKeys("jiya");

            //Password definition and input
            IWebElement Password = driver.FindElement(By.Id("Password"));
            Password.SendKeys("Jiya@345");

            //Login button definition and click
            IWebElement LoginButton = driver.FindElement(By.XPath("/html/body/div[3]/form/div/div/div/div[2]/div[3]/input"));
            LoginButton.Click();

            //Verification
            string Welcome = driver.FindElement(By.XPath("//*[@id='container']/div/div/h2")).Text;

            if (Welcome == "Welcome")
                Console.WriteLine("Login Test Passed");
            else
                Console.WriteLine("Login Test Failed");
        }
    }
}
