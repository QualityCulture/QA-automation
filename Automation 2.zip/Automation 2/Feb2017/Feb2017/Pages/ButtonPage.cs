﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Feb2017.Pages
{
    class ButtonPage
    {
        public void AddButton(IWebDriver driver)
        {
            //Click on User Interface
            driver.FindElement(By.CssSelector("#menu-items > ul > li:nth-child(5) > a")).Click();

            //Explicit wait
            Thread.Sleep(500);

            //Click on Button
            driver.FindElement(By.CssSelector("#menu-items > ul > li.dropdown.open > ul > li:nth-child(3) > a")).Click();

            //Explicit wait
            Thread.Sleep(2000);

            //Click on Add new Record button
            driver.FindElement(By.XPath("//*[@id='grid']/div[1]/a")).Click();

            //Explicit wait
            Thread.Sleep(500);

            //Test Data init
            string ButtonName = "test15";
            string ButtonDisplayName = "test15";
            string PreCondition = "test15";
            string Value = "test15";


            //Enter Button name
            driver.FindElement(By.XPath("/html/body/div[6]/div[2]/div/div[2]/input")).SendKeys(ButtonName);

            //Enter Button Display Title
            driver.FindElement(By.XPath("/html/body/div[6]/div[2]/div/div[4]/input")).SendKeys(ButtonDisplayName);

            //Button Logo DDL
            driver.FindElement(By.XPath("/html/body/div[6]/div[2]/div/div[6]/span/span/span[2]/span")).Click();
            Thread.Sleep(500);
            driver.FindElement(By.XPath("/html/body/div[7]/div/ul/li[4]/table/tbody/tr/td[2]")).Click();

            //Enter Pre-condition
            driver.FindElement(By.XPath("/html/body/div[6]/div[2]/div/div[8]/input")).SendKeys(PreCondition);

            //Next screen DDL
            driver.FindElement(By.XPath("/html/body/div[6]/div[2]/div/div[10]/span/span/span[2]/span")).Click();
            Thread.Sleep(500);
            driver.FindElement(By.XPath("//*[@id='NEXT_SCREEN_DBID_listbox']/li[4]")).Click();

            //Enter Value update
            driver.FindElement(By.XPath("/html/body/div[6]/div[2]/div/div[12]/input")).SendKeys(Value);

            //Next stage DDL
            driver.FindElement(By.XPath("/html/body/div[6]/div[2]/div/div[14]/span/span/span[1]")).Click();
            Thread.Sleep(500);
            driver.FindElement(By.XPath("//*[@id='NEXT_STATE_DBID_listbox']/li[4]")).Click();
            Thread.Sleep(500);

            //Pending state DDL
            driver.FindElement(By.XPath("/html/body/div[6]/div[2]/div/div[16]/span/span/span[1]")).Click();
            Thread.Sleep(500);
            driver.FindElement(By.XPath("//*[@id='PENDING_STATE_DBID_listbox']/li[5]")).Click();
            Thread.Sleep(500);

            //Entity Type DDL
            driver.FindElement(By.XPath("/html/body/div[6]/div[2]/div/div[18]/span/span/span[1]")).Click();
            Thread.Sleep(500);
            driver.FindElement(By.XPath("//*[@id='ETT_DBID_listbox']/li[4]")).Click();
            Thread.Sleep(500);

            //Override theme DDL
            driver.FindElement(By.XPath("/html/body/div[6]/div[2]/div/div[20]/span[1]/span/span[1]")).Click();
            Thread.Sleep(500);
            driver.FindElement(By.XPath("/html/body/div[12]/div/ul/li[1]")).Click();
            Thread.Sleep(500);

            try
            {
                //Click on create button
                driver.FindElement(By.XPath("/html/body/div[6]/div[2]/div/div[27]/a[1]")).Click();
                Thread.Sleep(1000);

                //Click on OK(Alert)
                driver.SwitchTo().Alert().Accept();
                Thread.Sleep(2000);

                //Click on User Interface
                driver.FindElement(By.CssSelector("#menu-items > ul > li:nth-child(5) > a")).Click();

                //Explicit wait
                Thread.Sleep(500);

                //Click on Button
                driver.FindElement(By.CssSelector("#menu-items > ul > li.dropdown.open > ul > li:nth-child(3) > a")).Click();
                Thread.Sleep(2000);

                //Click on Button name filter
                driver.FindElement(By.XPath("//*[@id='grid']/div[3]/div/table/thead/tr/th[1]/a[1]/span")).Click();
                Thread.Sleep(500);

                //Enter the button name
                driver.FindElement(By.XPath("/html/body/div[5]/form/div[1]/input[1]")).SendKeys(ButtonName);

                //Click on filter button
                driver.FindElement(By.XPath("/html/body/div[5]/form/div[1]/div[2]/button[1]")).Click();
                Thread.Sleep(1000);

                string ActualBN = driver.FindElement(By.XPath("//*[@id='grid']/div[4]/table/tbody/tr/td[1]")).Text;

                //Verify the button name
                if (ActualBN == ButtonName)
                {
                    Console.WriteLine("Button added successfully, Test2 passed");
                }
                else
                {
                    Console.WriteLine("Button not created, Test2 Failed");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception occured" + e.Message);
            }


        }
    }   
    
}
